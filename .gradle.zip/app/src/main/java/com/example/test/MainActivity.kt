package com.example.test

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.RatingBar
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_main.*

 class MainActivity : AppCompatActivity() {

     //lateinit var _editTextName:EditText
    // lateinit var ratingBar: RatingBar
    // lateinit var buttonSave: Button

     override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // editTextName=findViewById(R.id.editTextName)
        // ratingBar=findViewById(R.id.ratingBar)
       //  buttonSave=findViewById(R.id.Button)

       //  buttonSave.setOnClickListener {
       //      saveHero()
      //   }
       //  private fun saveHero(){
         //    val name = editTextName.text.toString().trim()
         //    if (name.isEmpty()){
          //       editTextName.error = "Please enter a name"
          //       return
           //  }
       //  }

      var imageView: ImageView=findViewById(R.id.ImageView)
        var url:String ="https://i.imgur.com/tGbaZCY.jpg";
       Picasso.get().load(url).into(imageView)
    }

}